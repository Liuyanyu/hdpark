<template>
  <bm-overlay ref="customOverlay" class="sample " pane="labelPane" @draw="draw">
    <slot></slot>
  </bm-overlay>
</template>

<script>
export default {
  props: ["text", "position", "active"],
  watch: {
    position: {
      handler() {
        this.$refs.customOverlay.reload();
      },
      deep: true
    }
  },
  methods: {
    handleClick() {
      global.alert("Well done.");
    },
    draw({ el, BMap, map }) {
      const { lng, lat } = this.position;
      const pixel = map.pointToOverlayPixel(new BMap.Point(lng, lat));
      el.style.left = pixel.x - 20 + "px";
      el.style.top = pixel.y - 20 + "px";
    }
  }
};
</script>

<style>
.sample {
  width: 120px;
  height: 40px;
  line-height: 40px;
  color: #fff;
  position: absolute;
}
</style>

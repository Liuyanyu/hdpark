<template>
  <div class="welcome__wrapper">
    <common-header></common-header> 
    <router-view />
    <template>
      <div id="map">
        <baidu-map
          class="baidumap"
          id="baidumap"
          :center="center"
          :zoom="zoom"
          @ready="handler"
        ></baidu-map>
      </div>
    </template>

    <div class="screenLeft">
      <p class="navTit">交通详情</p>
      <div class="scrollBar">
        <div class="water">
          <div class="waterMonitor">
            <div class="asideBg comTop">
              <span class="waterMonitorTit">入园人数</span>
              <span class="right">water monitoring</span>
            </div>
            <div class="comTop" style="margin-top:10px">
              <span>入园人数</span>
              <p class="lineHeightValue">Historical warning times</p>
              <p class="right hisWarn">
                <span class="warnValue">{{ inFlowTotal }}</span>
                <span>人</span>
              </p>
            </div>
            <div class="comTop" style="margin-top:10px">
              <span>今日在园人数</span>
              <p class="warmTimeEng lineHeightValue">
                Number of warnings yesterday
              </p>
              <p class="right hisWarn">
                <span class="warnValue">{{ inFlowToday }}</span>
                <span>人</span>
              </p>
            </div>
          </div>
          <div>
            <div class="asideBg comTop" style="margin-top:15px">
              <span class="waterMonitorTit">入园人数趋势</span>
              <span class="right">water monitoring</span>
            </div>
            <div class="comTop">
              <button
                class="pointLeft monitorPoint"
                style="width: 20%;margin-left: 67.5%"
                @click="demand"
              >
                查询
              </button>
            </div>

            <div class="comTop">
              <span class="monitorPoint">间隔选择</span>
              <select name="sel" v-model="timeIntervalValue">
                <option
                  v-for="item in timeIntervalOptions"
                  :key="item.timeIntervalValue"
                  :label="item.timeIntervalLabel"
                  :value="item.timeIntervalValue"
                ></option>
              </select>
              <span class="monitorPoint1">类别选择</span>
              <select v-model="WaterCategorySelectionValue" class="sel">
                <option
                  v-for="item in WaterCategorySelectionOptions"
                  :key="item.WaterCategorySelectionValue"
                  :label="item.WaterCategorySelectionLabel"
                  :value="item.WaterCategorySelectionValue"
                ></option>
              </select>
            </div>
            <div v-if="timeIntervalValue == '日'" class="comTop">
              <label class="monitorPoint">时间选择</label>
              <el-date-picker
                class="dateLeft"
                type="date"
                placeholder="选择日期"
                value-format="yyyy-MM-dd"
                @change="getStartDate1"
                v-model="getTime1.getStartTimeDate"
                :picker-options="pickerStartTimeDate"
              >
              </el-date-picker>
              <el-date-picker
                class="mediaStyle"
                type="date"
                placeholder="选择日期"
                @change="getEndDate1"
                value-format="yyyy-MM-dd"
                v-model="getTime1.getEndTimeDate"
                :picker-options="pickerEndTimeDate"
              >
              </el-date-picker>
            </div>
            <div v-if="timeIntervalValue == '月'" class="comTop">
              <label class="monitorPoint">时间选择</label>
              <el-date-picker
                class="dateLeft"
                type="month"
                placeholder="选择月"
                value-format="yyyy-MM"
                @change="getStartMonth1"
                v-model="getTime1.getStartTimeDate"
                :picker-options="pickerStartTimeDate"
              >
              </el-date-picker>
              <el-date-picker
                class="mediaStyle"
                type="month"
                placeholder="选择月"
                value-format="yyyy-MM"
                @change="getEndMonth1"
                v-model="getTime1.getEndTimeDate"
                :picker-options="pickerEndTimeDate"
              >
              </el-date-picker>
            </div>
            <div v-if="timeIntervalValue == '年'" class="comTop">
              <label class="monitorPoint">时间选择</label>
              <el-date-picker
                class="dateLeft"
                align="right"
                type="year"
                placeholder="选择年"
                value-format="yyyy"
                @change="getStartYear1"
                v-model="getTime1.getStartTimeDate"
                :picker-options="pickerStartTimeDate"
              >
              </el-date-picker>
              <el-date-picker
                class="mediaStyle"
                align="right"
                type="year"
                placeholder="选择年"
                value-format="yyyy"
                @change="getEndYear1"
                v-model="getTime1.getEndTimeDate"
                :picker-options="pickerEndTimeDate"
              >
              </el-date-picker>
            </div>
          </div>

          <div class="chart comTop"></div>
        </div>
        <div class="water">
          <div class="waterMonitor">
            <div class="asideBg comTop" style="margin-top:15px">
              <span class="waterMonitorTit">停车场数据</span>
              <span class="right">water monitoring</span>
            </div>
            <div class="comTop" style="margin-top:10px">
              <span>剩余车位</span>
              <p class="lineHeightValue">Historical warning times</p>
              <p class="right hisWarn">
                <span class="warnValue">{{ now }}</span>
                <span>次</span>
              </p>
            </div>
            <div class="comTop" style="margin-top:10px">
              <span>今日累计车次</span>
              <p class="warmTimeEng lineHeightValue">
                Number of warnings yesterday
              </p>
              <p class="right hisWarn">
                <span class="warnValue">{{ count }}</span>
                <span>次</span>
              </p>
            </div>
          </div>
          <div>
            <div class="comTop" style="margin-top:25px">
              <span class="monitorPoint">间隔选择</span>
              <select name="sel" v-model="timeIntervalValue1">
                <option
                  v-for="item in timeIntervalOptions1"
                  :key="item.timeIntervalValue1"
                  :label="item.timeIntervalLabel1"
                  :value="item.timeIntervalValue1"
                ></option>
              </select>
              <button
                class="pointLeft monitorPoint"
                style="width:19.5%"
                @click="demandPark"
              >
                查询
              </button>
            </div>
            <div v-if="timeIntervalValue1 == '日'" class="comTop">
              <label class="monitorPoint">时间选择</label>
              <el-date-picker
                class="dateLeft"
                type="date"
                placeholder="选择日期"
                value-format="yyyy-MM-dd"
                @change="getStartDate2"
                v-model="getTime2.getStartTimeDate"
                :picker-options="pickerStartTimeDate"
              >
              </el-date-picker>
              <el-date-picker
                class="mediaStyle"
                type="date"
                placeholder="选择日期"
                @change="getEndDate2"
                value-format="yyyy-MM-dd"
                v-model="getTime2.getEndTimeDate"
                :picker-options="pickerEndTimeDate"
              >
              </el-date-picker>
            </div>
            <div v-if="timeIntervalValue1 == '月'" class="comTop">
              <label class="monitorPoint">时间选择</label>
              <el-date-picker
                class="dateLeft"
                type="month"
                placeholder="选择月"
                value-format="yyyy-MM"
                @change="getStartMonth2"
                v-model="getTime2.getStartTimeDate"
                :picker-options="pickerStartTimeDate"
              >
              </el-date-picker>
              <el-date-picker
                class="mediaStyle"
                type="month"
                placeholder="选择月"
                value-format="yyyy-MM"
                @change="getEndMonth2"
                v-model="getTime2.getEndTimeDate"
                :picker-options="pickerEndTimeDate"
              >
              </el-date-picker>
            </div>
            <div v-if="timeIntervalValue1 == '年'" class="comTop">
              <label class="monitorPoint">时间选择</label>
              <el-date-picker
                class="dateLeft"
                align="right"
                type="year"
                placeholder="选择年"
                value-format="yyyy"
                @change="getStartYear2"
                v-model="getTime2.getStartTimeDate"
                :picker-options="pickerStartTimeDate"
              >
              </el-date-picker>
              <el-date-picker
                class="mediaStyle"
                align="right"
                type="year"
                placeholder="选择年"
                value-format="yyyy"
                @change="getEndYear2"
                v-model="getTime2.getEndTimeDate"
                :picker-options="pickerEndTimeDate"
              >
              </el-date-picker>
            </div>
          </div>
          <div class="chart"></div>
        </div>
      </div>
    </div>
    <common-footer></common-footer> 
    <router-view />
  </div>
</template>

<script>
import CommonHeader from "@commons/CommonHeader";
import CommonFooter from "@commons/CommonFooter";
import https from "@/https.js";
import carIcon from "@assets/marker/car.png";
export default {
  directives: {},
  mixins: [],
   components: { CommonHeader, CommonFooter },
  props: {},
  data() {
    return {
      inFlowTotal: "",
      inFlowToday: "",

      startInFlowValue: [],
      endInFlowValue: [],

      // 停车场
      carInflowStartData: "",
      carInflowStartTime: "",
      carInflowStartValue: "",

      carInflowEndData: "",
      carInflowEndTime: "",
      carInflowEndValue: "",

      count: "",
      now: "",
      center: { lng: 0, lat: 0 },
      zoom: 3,
      WaterCategorySelectionValue: "总入园人数",
      WaterCategorySelectionOptions: [
        {
          WaterCategorySelectionValue: "总入园人数",
          WaterCategorySelectionLabel: "总入园人数"
        },
        {
          WaterCategorySelectionValue: "东门入园人数",
          WaterCategorySelectionLabel: "东门入园人数"
        },
        {
          WaterCategorySelectionValue: "西门入园人数",
          WaterCategorySelectionLabel: "西门入园人数"
        }
      ],
      timeIntervalValue: "日",
      timeIntervalOptions: [
        {
          timeIntervalValue: "年",
          timeIntervalLabel: "年"
        },
        {
          timeIntervalValue: "月",
          timeIntervalLabel: "月"
        },
        {
          timeIntervalValue: "日",
          timeIntervalLabel: "日"
        }
      ],
      timeIntervalValue1: "日",
      timeIntervalOptions1: [
        {
          timeIntervalValue1: "年",
          timeIntervalLabel1: "年"
        },
        {
          timeIntervalValue1: "月",
          timeIntervalLabel1: "月"
        },
        {
          timeIntervalValue1: "日",
          timeIntervalLabel1: "日"
        }
      ],
      // 开始和结束时间不能超过当天
      pickerStartTimeDate: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      pickerEndTimeDate: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      getTime1: {
        getStartTimeDate: "",
        getEndTimeDate: ""
      },
      getTime2: {
        getStartTimeDate: "",
        getEndTimeDate: ""
      },
      // 在园人数图表
      startValue: "",
      startDate: "",
      endValue: "",
      endData: "",
      inFlowStartData: "",
      inFlowEndData: "",
      //停车场图表
      carStartVal: "",
      carStartDate: "",
      carEndVal: "",
      carEndData: "",
      carInStartData: "",
      carInEndData: "",

      pumpMapPoints: []
    };
  },
  computed: {},
  watch: {},
  mounted() {},
  created() {
    this.getInflowTotal();
  },
  methods: {
    // 左侧入园人数
    getInflowTotal() {
      var that = this;
      https
        .fetchGet("url2/people/total")
        .then(function(response) {
          console.log(response);
          // 东门
          var eastPark = response.object.east;
          var inFlowEast = eastPark.inFlow;
          var outFlowEast = eastPark.outFlow;
          // 西门
          var westPark = response.object.west;
          var inFlowWest = westPark.inFlow;
          var outFlowWest = westPark.outFlow;
          // 入园人数
          that.inFlowTotal = inFlowEast + inFlowWest;
          console.log(that.inFlowTotal);
          // 在园人数
          that.inFlowToday =
            inFlowEast + inFlowWest - outFlowEast - outFlowWest;
          console.log(that.inFlowToday);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    // 入园人数图表
    demand() {
      var that = this;
      var inFlowType = "";
      if (that.WaterCategorySelectionValue == "总入园人数") {
        inFlowType = 1;
      } else if (that.WaterCategorySelectionValue == "东门入园人数") {
        inFlowType = 2;
      } else if (that.WaterCategorySelectionValue == "西门入园人数") {
        inFlowType = 3;
      }
      let param = {
        startTime: that.getTime1.getStartTimeDate,
        endTime: that.getTime1.getEndTimeDate,
        type: inFlowType
      };
      https
        .fetchGet("/url2/people/totalPeople", param)
        .then(function(response) {
          that.inFlowStartData = response.object.list;
          for (var i = 0; i < that.inFlowStartData.length; i++) {
            that.startValue = that.inFlowStartData[i].inFlow;
            that.startDate = that.inFlowStartData[i].createTime;
          }
          console.log(that.startValue);
          that.inFlowEndData = response.object.contrastList;
          for (var i = 0; i < that.inFlowEndData.length; i++) {
            that.endValue = that.inFlowEndData[i].inFlow;
            that.endData = that.inFlowEndData[i].createTime;
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    // 停车场图表
    demandPark() {
      var that = this;
      let param = {
        startTime: this.getTime2.getStartTimeDate,
        enTime: this.getTime2.getEndTimeDate
      };
      https
        .fetchGet("url2/parking/chart", param)
        .fetchGet("")
        .then(function(response) {
          that.carInStartData = response.object.list;
          for (var i = 0; i < that.inFlowStartData.length; i++) {
            that.carStartVal = that.inFlowStartData[i].carInflow;
            that.carStartDate = that.inFlowStartData[i].createTime;
          }
          that.carInEndData = response.object.contrastList;
          for (var i = 0; i < that.inFlowStartData.length; i++) {
            that.carEndVal = that.inFlowStartData[i].carInflow;
            that.carEndData = that.inFlowStartData[i].createTime;
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    // drawChart() {
    //   let _this = this;
    //   let myChart1 = this.$echarts.init(document.getElementById("myChart1"));
    //   myChart1.setOption({
    //     grid: {
    //       y: 10,
    //       height: 80,
    //       y2: 20
    //     },
    //     xAxis: {
    //       type: "category",
    //       data: _this.waterCreatTime,
    //       axisLine: {
    //         lineStyle: {
    //           color: "#fff"
    //         }
    //       },
    //       axisLabel: {
    //         interval: 4
    //       }
    //     },
    //     yAxis: {
    //       type: "value",
    //       axisLine: {
    //         lineStyle: {
    //           color: "#fff"
    //         }
    //       }
    //     },
    //     // color: ["#00b4fe", "#00b4fe", "#00b4fe"],
    //     series: [
    //       {
    //         data: _this.startInFlowValue,
    //         type: "line",
    //         smooth: true,
    //         color: "#ff0000",
    //         lineStyle: {
    //           color: "#ff0000"
    //         },
    //         label: {
    //           normal: {
    //             show: true,
    //             position: "top"
    //           }
    //         }
    //       },
    //       {
    //         data: _this.endInFlowValue,
    //         type: "line",
    //         smooth: true,
    //         color: "#04DDDA",
    //         lineStyle: {
    //           color: "#04DDDA"
    //         },
    //         label: {
    //           normal: {
    //             show: true,
    //             position: "top"
    //           }
    //         }
    //       }
    //     ]
    //   });
    // },

    // // 停车场数据
    // drawInflowChart() {
    //   var that = this;
    //   let myChart2 = this.$echarts.init(document.getElementById("myChart2"));
    //   myChart2.setOption({
    //     grid: {
    //       y: 10,
    //       height: 80,
    //       y2: 20
    //     },
    //     xAxis: {
    //       type: "category",
    //       data: that.carInflowStartTime,
    //       axisLine: {
    //         lineStyle: {
    //           color: "#fff"
    //         }
    //       }
    //     },
    //     yAxis: {
    //       type: "value",
    //       axisLine: {
    //         lineStyle: {
    //           color: "#fff"
    //         }
    //       }
    //     },
    //     series: [
    //       {
    //         data: that.carInflowStartValue,
    //         type: "line",
    //         smooth: true,
    //         color: "#00ffff",
    //         lineStyle: {
    //           color: "#00ffff"
    //         }
    //       },
    //       {
    //         data: that.carInflowEndValue,
    //         type: "line",
    //         smooth: true,
    //         color: "#22ac38",
    //         lineStyle: {
    //           color: "#22ac38"
    //         }
    //       }
    //     ]
    //   });
    // },
    handler({ BMap, map }) {
      var _this = this;
      // 地图中心点
      this.center.lng = 116.302281;
      this.center.lat = 39.992571;
      this.zoom = 17;
      // var mapStyle = { style: "midnight" };
      // map.setMapStyle(mapStyle);
      map.enableScrollWheelZoom();
      // map.setMapType(BMAP_PERSPECTIVE_MAP);
      // 停车场
      https
        .fetchGet("url2/parking/now")
        .then(function(response) {
          var pumpData = response.object.list;
          console.log(pumpData);
          var pumpMapPoints = [];
          for (var i = 0; i < pumpData.length; i++) {
            pumpMapPoints.push({
              x: pumpData[i].latitude,
              y: pumpData[i].longitude,
              parkingName: pumpData[i].parkingName,
              now: pumpData[i].now,
              count: pumpData[i].count,
              parkingTotalNum: pumpData[i].parkingTotalNum
            });
            _this.count = pumpData[i].count;
            _this.now = pumpData[i].now;
          }
          _this.pumpMapPoints = pumpMapPoints;

          for (var i = 0; i < _this.pumpMapPoints.length; i++) {
            var content = `<div class="deviceBg">`;
            content =
              content +
              `<div class="title" style=" display: flex">
                  <button id="waterName" style="flex:1;border: none;background-color: transparent;outline: none;">水循环水泵</button>
                  <button id="waterTab" style="flex:1;border: none;background-color: transparent;outline: none;">控制面板</button></div>`;
            content = content + `<div id="deviceInfo">`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">位置 : ` +
              _this.pumpMapPoints[i].parkingName +
              `</p>`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">总停车位 : ` +
              _this.pumpMapPoints[i].parkingTotalNum +
              `</p>`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">剩余车位 : ` +
              _this.pumpMapPoints[i].now +
              `</p>`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">今日停泊车次 : ` +
              _this.pumpMapPoints[i].count +
              `</p>`;
            content = content + `</div>`;
            content =
              content +
              `<div class="reportForm" id="reportForm" style="display:none">`;
            content = content + `<span>阀门控制</span>`;
            content = content + ` </div>`;
            content += `</div>`;
            //创建坐标点
            var points = new BMap.Point(
              _this.pumpMapPoints[i].y,
              _this.pumpMapPoints[i].x
            );
            var opts = {
              width: 120,
              height: 125
            };
            var infoWindows = new BMap.InfoWindow(content, opts);
            markerFun(points, infoWindows);
            function markerFun(points, infoWindows) {
              var puIcon = new BMap.Icon(carIcon, new BMap.Size(100, 100));
              var markers = new BMap.Marker(points, { icon: puIcon });

              map.addOverlay(markers);

              var label = new BMap.Label(_this.pumpMapPoints[i].parkingName, {
                offset: new BMap.Size(-20, 40)
              });
              var labelStyle = {
                border: "0",
                color: "#000000"
              };
              label.setStyle(labelStyle);
              markers.setLabel(label);
              markers.addEventListener("click", function() {
                map.openInfoWindow(infoWindows, points); //参数：窗口、点  根据点击的点出现对应的窗口
              });
            }
            if (!infoWindows.isOpen()) {
              infoWindows.addEventListener("open", function(e) {
                var waterName = document.getElementById("waterName");
                waterName.onclick = function() {
                  console.log("监测点");
                  document.getElementById("deviceInfo").style.display = "block";
                  document.getElementById("reportForm").style.display = "none";
                };
                var waterTab = document.getElementById("waterTab");
                waterTab.onclick = function() {
                  console.log("报表");
                  document.getElementById("deviceInfo").style.display = "none";
                  document.getElementById("reportForm").style.display = "block";
                };
              });
            } else {
              var waterName = document.getElementById("waterName");
              waterName.onclick = function() {
                console.log("监测点");
                document.getElementById("deviceInfo").style.display = "block";
                document.getElementById("reportForm").style.display = "none";
              };
              var waterTab = document.getElementById("waterTab");
              waterTab.onclick = function() {
                console.log("报表");
                document.getElementById("deviceInfo").style.display = "none";
                document.getElementById("reportForm").style.display = "block";
              };
            }
          }
          console.log(content);
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  }
};
</script>
<style lang="stylus" scoped>
.baidumap
  width 100%
  height 100%
  position absolute
</style>

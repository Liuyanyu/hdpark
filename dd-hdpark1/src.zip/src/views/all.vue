<template>
  <div style="padding: 20px;">
    <el-row :gutter="20">
      <el-col :span="4">
        <div>
          <el-select v-model="value1" multiple placeholder="设备选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </div>
      </el-col>
      <el-col :span="4">
        <el-date-picker
          value-format="yyyy-MM-dd"
          format="yyyy-MM-dd"
          v-model="startYtd"
          type="date"
          placeholder="选择日期"
        ></el-date-picker>
      </el-col>
      <el-col :span="4">
        <el-date-picker
          value-format="yyyy-MM-dd"
          format="yyyy-MM-dd"
          v-model="endYtd"
          type="date"
          placeholder="选择日期"
        ></el-date-picker>
      </el-col>
      <el-col :span="5" class="right" style="line-height:40px;font-size:15px">
        <span>累计告警次数:0</span>
      </el-col>
      <el-col :span="4" class="right" style="line-height:40px;font-size:15px">
        <span>今日告警次数:0</span>
      </el-col>
    </el-row>
    <div class="main">
      <div class="aside">
        <div
          style="width:93.5%;margin-left:2%;height:150px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);padding:20px;line-height:30px;font-size:13px"
        >
          <div>
            <span style="color:#E17014">土壤监测点</span>
            <el-button type="primary" plain class="right">人工处理</el-button>
          </div>
          <div style="color:#C0C1C1">
            <el-row :gutter="20">
              <el-col :span="16">告警原因及建议</el-col>
              <el-col :span="4" style="text-align: right;">负责人</el-col>
              <el-col :span="4" style="text-align: right;">2020.12.3</el-col>
            </el-row>
          </div>
          <div style="color:#15C8DB">
            <el-row :gutter="20">
              <el-col :span="8">提示时间</el-col>
              <el-col :span="8">结束时间</el-col>
              <el-col :span="4" style="text-align: right;">响应时间</el-col>
              <el-col :span="4" style="text-align: right;">持续时间</el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
// import https from "@/https.js";
// import axios from "axios";
export default {
  data() {
    return {
      options: [
        {
          value: "选项1",
          label: "黄金糕"
        },
        {
          value: "选项2",
          label: "双皮奶"
        },
        {
          value: "选项3",
          label: "蚵仔煎"
        },
        {
          value: "选项4",
          label: "龙须面"
        },
        {
          value: "选项5",
          label: "北京烤鸭"
        }
      ],
      value1: []
    };
  },
  created() {},
  computed: {},
  mounted() {},
  methods: {}
};
</script>
<style scoped lang="scss">
.el-row {
  margin-bottom: 20px;
  &:last-child {
    margin-bottom: 0;
  }
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
.main {
  width: 90%;
  height: 70vh;
  overflow-y: scroll;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  padding-top: 20px;
  overflow-y: scroll;
}
.aside {
  width: 100%;
  height: 200px;
}
.main::-webkit-scrollbar {
  display: none;
}
</style>

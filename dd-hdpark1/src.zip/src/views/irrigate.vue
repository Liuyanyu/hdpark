<template>
  <div class="welcome__wrapper">
    <common-header></common-header>
    <router-view />

    <!-- <template>
      <div id="map">
        <baidu-map class="baidumap" id="baidumap" :center="center" :zoom="zoom" @ready="handler"></baidu-map>
      </div>
    </template>-->

    <template>
      <baidu-map class="baidumap" :center="center" :zoom="zoom" @ready="handler">
        <bml-marker-clusterer :averageCenter="true">
          <div v-for="(marker, i) of markers" :key="i">
            <bm-marker
              :dragging="true"
              :icon="{url:'../src/assets/marker/irr.png', size: { width: 300, height: 171 }}"
              :position="{lng: marker.lng, lat: marker.lat}"
              @click="infoWindowOpen(marker)"
            >
              <bm-info-window
                title="弹窗信息"
                :position="{lng: marker.lng, lat: marker.lat}"
                :show="marker.showFlag"
                @close="infoWindowClose(marker)"
                @open="infoWindowOpen(marker)"
              >
                <p v-text="infoWindow.contents"></p>
              </bm-info-window>
            </bm-marker>
          </div>
        </bml-marker-clusterer>
      </baidu-map>
    </template>

    <div class="screenLeft">
      <div class="water">
        <p class="navTit">智能灌溉</p>
        <div class="waterMonitor">
          <div class="asideBg comTop">
            <span class="waterMonitorTit">灌溉分析</span>
            <span class="right">water monitoring</span>
          </div>
        </div>
        <div class="electricity-show-img">
          <div class="img-item">
            <div class="circle__wrapper">
              <div class="value" style="color:#00FFFF">{{ total }}</div>
              <div class="unit" style="color:#00FFFF">kw/h</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#00FFFF">总耗水量</div>
          </div>
          <div class="img-item">
            <div class="circle__wrapper">
              <div class="value" style="color:#00FFFF">{{ yesterday }}</div>
              <div class="unit" style="color:#00FFFF">kw/h</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#00FFFF">昨日用水</div>
          </div>
          <div class="img-item">
            <div class="circle__wrapper">
              <div class="value" style="color:#00FFFF">{{ economizeWater }}</div>
              <div class="unit" style="color:#00FFFF">kw/h</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#00FFFF">节省水量</div>
          </div>
          <div class="img-item">
            <div class="circle__wrapper1">
              <div class="value" style="color:#FFAE11">{{ economizeMoney }}</div>
              <div class="unit" style="color:#FFAE11">万元</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#FFAE11">节省金额</div>
          </div>
        </div>
        <div style="margin-top:10px">
          <span>上月节省水量</span>
          <span class="right">m³</span>
        </div>
        <div style="margin-top:10px">
          <span class>上月节省金额</span>
          <span class="right">m³</span>
        </div>
        <div style="margin-top:10px">
          <span class>上月智能灌溉区用水量</span>
          <span class="right">{{ yesSmartTotal }}</span>
        </div>
        <div style="margin-top:10px">
          <span class>上月普通区灌溉用水量</span>
          <span class="right">{{ yesNormalTotal }}</span>
        </div>

        <div class="waterAlarm">
          <div class="asideBg" style="margin-top:10px">
            <span class="waterMonitorTit">各项水量使用情况</span>
            <span class="right">water alarm record</span>
          </div>
          <div class="comTop">
            <div class="percent">
              <span>智能灌溉区</span>
              <span class="percentValue">{{ smartTotal }}</span>
              <span>m³</span>
            </div>
            <el-progress :percentage="smart"></el-progress>
            <div style="clear:both"></div>
          </div>
          <div class="comTop">
            <div class="percent">
              <span>普通灌溉区</span>
              <span class="percentValue">{{ normalTotal }}</span>
              <span>m³</span>
            </div>
            <el-progress :percentage="normal"></el-progress>
            <div style="clear:both"></div>
          </div>
        </div>
      </div>
      <div class="water">
        <div class="waterMonitor">
          <div class="asideBg comTop">
            <span class="waterMonitorTit">用水趋势</span>
            <span class="right">water monitoring</span>
          </div>
        </div>

        <div>
          <div class="comTop">
            <button
              class="pointLeft monitorPoint"
              style="width: 20%;margin-left: 67.5%"
              @click="demand"
            >查询</button>
          </div>
          <div class="comTop">
            <span class="monitorPoint">间隔选择</span>
            <select name="sel" v-model="timeIntervalValue">
              <option
                v-for="item in timeIntervaloptions"
                :key="item.timeIntervalValue"
                :label="item.timeIntervalLabel"
                :value="item.timeIntervalValue"
              ></option>
            </select>
            <span class="monitorPoint1">类别选择</span>
            <select class="sel" v-model="value">
              <option
                v-for="item in waterTypeList"
                :key="item.value"
                :value="item.value"
              >{{item.label}}</option>
            </select>
          </div>
          <div>
            <div v-if="timeIntervalValue == '日'" class="comTop">
              <span class="monitorPoint">时间选择</span>
              <select v-model="selectYear" class style="margin-right:4%">
                <option
                  v-for="item in selectYearList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectMonth" class style="margin-right:4%">
                <option
                  v-for="item in selectMonthList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectDay" class style="margin-right:4%">
                <option
                  v-for="item in selectDayList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectYear1" class="comTop" style="margin-right:4%;margin-left:19%">
                <option
                  v-for="item in selectYearList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectMonth1" class="comTop" style="margin-right:4%">
                <option
                  v-for="item in selectMonthList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectDay1" class="comTop" style="margin-right:4%">
                <option
                  v-for="item in selectDayList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
            </div>
            <div v-if="timeIntervalValue == '月'" class="comTop">
              <span class="monitorPoint">时间选择</span>
              <select v-model="selectYear" style="margin-right: 4%;">
                <option
                  v-for="item in selectYearList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectMonth" class>
                <option
                  v-for="item in selectMonthList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <!-- <div class="comTop" style="margin-left: 19%;"> -->
              <select
                v-model="selectYear1"
                style="margin-right: 4%;margin-left: 19%;"
                class="comTop"
              >
                <option
                  v-for="item in selectYearList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectMonth1" class>
                <option
                  v-for="item in selectMonthList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <!-- </div> -->
            </div>
            <div v-if="timeIntervalValue == '年'" class="comTop">
              <span class="monitorPoint">时间选择</span>
              <select v-model="selectYear" style="margin-right: 4%;">
                <option
                  v-for="item in selectYearList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
              <select v-model="selectYear1" class="comTop" style="margin-left: 19%;display:block">
                <option
                  v-for="item in selectYearList"
                  :value="item.value"
                  :key="item.value"
                >{{ item.label }}</option>
              </select>
            </div>
          </div>
        </div>

        <div class="chart" id="myChart1"></div>

        <div class="waterAlarm">
          <div class="asideBg comTop">
            <span class="waterMonitorTit">土壤墒情记录</span>
            <span class="right">water alarm record</span>
          </div>
          <div class="comTop">
            <span class="monitorPoint">时间选择</span>
            <select v-model="selectWarnYear1" class style="margin-right:4%;width:18%">
              <option
                v-for="item in selectYearList"
                :value="item.value"
                :key="item.value"
              >{{ item.label }}</option>
            </select>
            <select v-model="selectWarnMonth1" class style="margin-right:4%;width:18%">
              <option
                v-for="item in selectMonthList"
                :value="item.value"
                :key="item.value"
              >{{ item.label }}</option>
            </select>
            <select v-model="selectWarnDay1" class style="margin-right:4%;width:18%">
              <option
                v-for="item in selectDayList"
                :value="item.value"
                :key="item.value"
              >{{ item.label }}</option>
            </select>
            <button class="pointLeft monitorPoint" style="width: 15%;margin-left:0">查询</button>
          </div>
          <div class="comTop alarmStat">
            <span style="flex:1;text-align:left">灌溉用水</span>
            <span style="flex:1;text-align:left">灌溉时长</span>
            <span style="flex:1.5;text-align:center">起末土壤墒情</span>
            <span style="flex:1;text-align:right">上升比例</span>
            <span style="flex:1;text-align:center">时间</span>
          </div>
        </div>
      </div>
    </div>
    <common-footer></common-footer>
    <router-view />
  </div>
</template>
<script>
import CommonHeader from "@commons/CommonHeader";
import CommonFooter from "@commons/CommonFooter";
// import irrIcon from "@assets/marker/irr.png";
// import soilIcon from "@assets/marker/soil.png";

// import irrIcon1 from "@assets/marker/irr1.png";
import https from "@/https.js";
export default {
  directives: {},
  components: { CommonHeader, CommonFooter },
  mixins: [],
  props: {},
  data() {
    return {
      markers: [],
      // infoWindow: {
      //   show: true,
      //   contents:
      //     "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
      // },
      mapSelect: [
        {
          mapValue: "年",
          mapLabel: "年"
        },
        {
          mapValue: "月",
          mapLabel: "月"
        },
        {
          mapValue: "日",
          mapLabel: "日"
        }
      ],
      mapValue: "日",
      selectYearList: [
        { value: "2019", label: "2019" },
        { value: "2020", label: "2020" }
      ],
      selectMonthList: [
        { value: "01", label: "01" },
        { value: "02", label: "02" },
        { value: "03", label: "03" },
        { value: "04", label: "04" },
        { value: "05", label: "05" },
        { value: "06", label: "06" },
        { value: "07", label: "07" },
        { value: "08", label: "08" },
        { value: "09", label: "09" },
        { value: "10", label: "10" },
        { value: "11", label: "11" },
        { value: "12", label: "12" }
      ],
      selectDayList: [
        { value: "01", label: "01" },
        { value: "02", label: "02" },
        { value: "03", label: "03" },
        { value: "04", label: "04" },
        { value: "05", label: "05" },
        { value: "06", label: "06" },
        { value: "07", label: "07" },
        { value: "08", label: "08" },
        { value: "09", label: "09" },
        { value: "10", label: "10" },
        { value: "11", label: "11" },
        { value: "12", label: "12" },
        { value: "13", label: "13" },
        { value: "14", label: "14" },
        { value: "15", label: "15" },
        { value: "16", label: "16" },
        { value: "17", label: "17" },
        { value: "18", label: "18" },
        { value: "19", label: "19" },
        { value: "20", label: "20" },
        { value: "21", label: "21" },
        { value: "22", label: "22" },
        { value: "23", label: "23" },
        { value: "24", label: "24" },
        { value: "25", label: "25" },
        { value: "26", label: "26" },
        { value: "27", label: "27" },
        { value: "28", label: "28" },
        { value: "29", label: "29" },
        { value: "30", label: "30" },
        { value: "31", label: "31" }
      ],
      selectYear: "2019",
      selectMonth: "06",
      selectDay: "15",
      selectYear1: "2020",
      selectMonth1: "02",
      selectDay1: "12",
      selectWarnYear1: "2019",
      selectWarnMonth1: "11",
      selectWarnDay1: "11",
      timeIntervaloptions: [
        {
          timeIntervalValue: "年",
          timeIntervalLabel: "年"
        },
        {
          timeIntervalValue: "月",
          timeIntervalLabel: "月"
        },
        {
          timeIntervalValue: "日",
          timeIntervalLabel: "日"
        }
      ],
      timeIntervalValue1: "日",
      waterTypeList: [
        { label: "全部", value: "10" },
        { label: "普通灌溉区", value: "1" },
        { label: "智能灌溉区", value: "2" }
      ],
      value: "10",
      smart: "20",
      normal: "40",
      yesterday: "",
      total: "",
      economizeMoney: "",
      economizeWater: "",
      smartTotal: "",
      normalTotal: "",
      yesSmartTotal: "",
      yesNormalTotal: "",
      showImgInfo: [
        { value: "20", unit: "kw/h", isMoney: false, label: "总耗水量" },
        { value: "20", unit: "kw/h", isMoney: false, label: "昨日用水" },
        { value: "20", unit: "kw/h", isMoney: false, label: "节省水量" },
        { value: "20", unit: "万元", isMoney: true, label: "节省金额" }
      ],
      yesterdayInfo: [
        {
          label: "昨日节省水量",
          value: "1241982.09",
          unit: "km/h",
          state: true
        },
        {
          label: "昨日节省金额",
          value: "1241982.09",
          unit: "km/h",
          state: true
        },
        {
          label: "昨日智能灌溉区用水量",
          value: "1241982.09",
          unit: "km/h",
          state: true
        },
        {
          label: "昨日普通灌溉区用水量",
          value: "1241982.09",
          unit: "km/h",
          state: true
        }
      ],
      electricitySomeInfo: [
        {
          label: "智能灌溉区",
          value: "2.3",
          unit: "kw/h",
          progress: "34",
          uping: true
        },
        {
          label: "普通灌溉区",
          value: "2.3",
          unit: "kw/h",
          progress: "34",
          uping: true
        }
      ],
      failureLogging: [
        {
          label: "10t",
          irrTinme: "01:00:00",
          soilEnd: "7%~15%",
          ratio: "7%",
          time: "20:00:23"
        },
        {
          label: "10t",
          irrTinme: "01:00:00",
          soilEnd: "7%~15%",
          ratio: "7%",
          time: "20:00:23"
        },
        {
          label: "10t",
          irrTinme: "01:00:00",
          soilEnd: "7%~15%",
          ratio: "7%",
          time: "20:00:23"
        },
        {
          label: "10t",
          irrTinme: "01:00:00",
          soilEnd: "7%~15%",
          ratio: "7%",
          time: "20:00:23"
        }
      ],
      waterStartChartData: "",
      waterStartCreatTime: "",
      waterStartTypeNum: "",

      waterEndChartData: "",
      waterEndCreatTime: "",
      waterEndTypeNum: "",

      center: { lng: 0, lat: 0 },
      zoom: 3,
      timeIntervalValue: "日",
      timeIntervalOptions: [
        {
          timeIntervalValue: "年",
          timeIntervalLabel: "年"
        },
        {
          timeIntervalValue: "月",
          timeIntervalLabel: "月"
        },
        {
          timeIntervalValue: "日",
          timeIntervalLabel: "日"
        }
      ],
      categoryOptions: [
        {
          categoryIntervalValue: "普通区",
          categoryIntervalLabel: "智慧区"
        }
      ],
      // 开始和结束时间不能超过当天
      pickerStartTimeDate: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      pickerEndTimeDate: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      getTime1: {
        getStartTimeDate: "",
        getEndTimeDate: "",
        getStartTimeMonth: "",
        getEndTimeMonth: "",
        getStartTimeYear: "",
        getEndTimeYear: ""
      }
    };
  },
  computed: {},
  watch: {},
  mounted() {},
  created() {
    this.IrrigateInfo();
    this.WaterNumTotal();
    this.yesWatTotal();
    this.demand();
    this.getPoint();
  },
  methods: {
    handler({ BMap, map }) {
      console.log(BMap, map);
      this.center.lng = 116.302281;
      this.center.lat = 39.992571;
      this.zoom = 17;
    },
    infoWindowClose(marker) {
      marker.showFlag = false;
      console.log(marker);
    },
    infoWindowOpen(marker) {
      marker.showFlag = true;
      console.log(marker);
    },
    getPoint() {
      var that = this;
      https
        .fetchGet("/soil/waterDevice/list")
        .then(function(res) {
          var data = res.object.list;
          for (var i = 0; i < data.length; i++) {
            that.markers.push({
              lng: data[i].longitude,
              lat: data[i].latitude
            });
          }
          console.log(that.markers[0]);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    isNumber: function(value) {
      if (value >= 1000) {
        return (
          Number((value / 10000).toString().match(/^\d+(?:\.\d{0,2})?/)) + "万"
        );
      } else if (value.toString().split(".").length > 2) {
        return Number(value.toString().match(/^\d+(?:\.\d{0,2})?/));
      } else {
        return value;
      }
    },
    demand() {
      var that = this;
      var startTime = "";
      var endTime = "";
      if (that.timeIntervalValue == "日") {
        startTime =
          that.selectYear + "-" + that.selectMonth + "-" + that.selectDay;
        endTime =
          that.selectYear1 + "-" + that.selectMonth1 + "-" + that.selectDay1;
      } else if (that.timeIntervalValue == "月") {
        startTime = that.selectYear + "-" + that.selectMonth;
        endTime = that.selectYear1 + "-" + that.selectMonth1;
      } else if (that.timeIntervalValue == "年") {
        startTime = that.selectYear;
        endTime = that.selectYear1;
      }
      let param = {
        startTime: startTime,
        endTime: endTime,
        type: that.value
      };
      https
        .fetchGet("/soil/energy/newWaterChart", param)
        .then(function(res) {
          console.log(res);
          // 开始
          that.waterStartChartData = res.object.list;
          that.waterStartCreatTime = [];
          that.waterStartTypeNum = [];
          for (var i = 0; i < that.waterStartChartData.length; i++) {
            that.waterStartCreatTime[i] =
              that.waterStartChartData[i].createTime;
            that.waterStartTypeNum[i] = that.waterStartChartData[i].thisNum;
          }

          console.log(that.waterStartCreatTime);
          console.log(that.waterStartTypeNum);
          // 结束
          that.waterEndChartData = res.object.contrastList;
          that.waterEndCreatTime = [];
          that.waterEndTypeNum = [];
          for (var i = 0; i < that.waterEndChartData.length; i++) {
            that.waterEndCreatTime[i] = that.waterEndChartData[i].createTime;
            that.waterEndTypeNum[i] = that.waterEndChartData[i].thisNum;
          }
          console.log(that.waterEndCreatTime);
          console.log(that.waterEndTypeNum);
          that.drawChart();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    drawChart() {
      let that = this;
      let myChart = this.$echarts.init(document.getElementById("myChart1"));
      console.log(that.waterStartTypeNum);
      console.log(that.timeIntervalValue);
      if (that.timeIntervalValue == "日") {
        that.xData = [
          "01",
          "02",
          "03",
          "04",
          "05",
          "06",
          "07",
          "08",
          "09",
          "10",
          "11",
          "12",
          "13",
          "14",
          "15",
          "16",
          "17",
          "18",
          "19",
          "20",
          "21",
          "22",
          "23",
          "24"
        ];
      } else if (that.timeIntervalValue == "月") {
        that.xData = [
          "01",
          "02",
          "03",
          "04",
          "05",
          "06",
          "07",
          "08",
          "09",
          "10",
          "11",
          "12",
          "13",
          "14",
          "15",
          "16",
          "17",
          "18",
          "19",
          "20",
          "21",
          "22",
          "23",
          "24",
          "25",
          "26",
          "27",
          "28",
          "29",
          "30",
          "31"
        ];
      } else if (that.timeIntervalValue == "年") {
        that.xData = [
          "01",
          "02",
          "03",
          "04",
          "05",
          "06",
          "07",
          "08",
          "09",
          "10",
          "11",
          "12"
        ];
      }
      console.log(that.xData);
      var options = {
        grid: {
          y: 10,
          height: 80,
          y2: 20
        },
        xAxis: {
          type: "category",
          data: that.xData,
          axisLine: {
            lineStyle: {
              color: "#fff"
            }
          }
        },
        yAxis: {
          type: "value",
          axisLine: {
            lineStyle: {
              color: "#fff"
            }
          }
        },
        series: [
          {
            data: that.waterStartTypeNum,
            // data: 0,
            type: "line",
            smooth: true,
            color: "#00ffff",
            lineStyle: {
              color: "#00ffff"
            }
          },
          {
            data: that.waterEndTypeNum,
            // data: 1,
            type: "line",
            smooth: true,
            color: "#22ac38",
            lineStyle: {
              color: "#22ac38"
            }
          }
        ]
      };
      try {
        myChart.setOption(options);
      } catch (err) {
        console.log(err);
      }
    },
    // 灌溉分析 圆
    IrrigateInfo() {
      var that = this;
      https
        .fetchGet("/soil/waterDevice/left")
        .then(function(response) {
          that.yesterday = that.isNumber(response.object.yesterday);
          that.total = that.isNumber(response.object.total);
          that.economizeMoney = that.isNumber(response.object.economizeMoney);
          that.economizeWater = that.isNumber(response.object.economizeWater);
          console.log(that.yesterday);
          console.log(that.total);
          console.log(that.economizeMoney);
          console.log(that.economizeWater);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    // 昨日用水量
    yesWatTotal() {
      var _this = this;
      https
        .fetchGet("/soil/waterDevice/yesterdayWaterTotal")
        .then(function(response) {
          console.log(response);
          _this.yesSmartTotal = response.object.smart;
          _this.yesNormalTotal = response.object.nornal;
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    // 各项水量使用情况 累计统计
    WaterNumTotal() {
      var _this = this;
      https
        .fetchGet("/soil/waterDevice/WaterNumTotal")
        .then(function(response) {
          console.log(response);
          _this.smartTotal = response.object.smart;
          _this.normalTotal = response.object.nornal;
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  }
};
</script>
<style lang="stylus" scoped>
.bm-view {
  width: 100%;
  height: 100%;
  position: absolute;
}

>>>.el-progress-bar__inner {
  background-color: rgb(0, 255, 255);
  height: 5px;
}

>>>.el-progress-bar__outer {
  height: 2px !important;
  border-radius: 100px;
  overflow: inherit;
  background-color: rgb(0, 255, 255);
  position: relative;
  vertical-align: middle;
}

.mapAside {
  line-height: 20px;
  margin: 0px;
  margin-left: 10px;
}
</style>

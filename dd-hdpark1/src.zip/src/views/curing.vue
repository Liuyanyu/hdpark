<template>
  <div class="welcome__wrapper">
    <common-header></common-header> 
    <router-view />
    <template>
      <div id="map">
        <baidu-map
          class="baidumap"
          id="baidumap"
          :center="center"
          :zoom="zoom"
          @ready="handler"
        ></baidu-map>
      </div>
    </template>
    <div class="screenLeft">
      <div class="water">
        <p class="navTit">智能养护</p>
        <div class="waterMonitor">
          <div class="asideBg comTop">
            <span class="waterMonitorTit">智能垃圾桶感应数据</span>
            <span class="right">water monitoring</span>
          </div>
        </div>
        <div class="electricity-show-img">
          <div class="img-item">
            <div class="circle__wrapper">
              <div class="value" style="color:#00FFFF">{{ recyclable }}</div>
              <div class="unit" style="color:#00FFFF">次</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#00FFFF">
              瓶类垃圾
            </div>
          </div>
          <div class="img-item">
            <div class="circle__wrapper">
              <div class="value" style="color:#00FFFF">{{ pager }}</div>
              <div class="unit" style="color:#00FFFF">次</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#00FFFF">
              纸类垃圾
            </div>
          </div>
          <div class="img-item">
            <div class="circle__wrapper">
              <div class="value" style="color:#00FFFF">{{ other }}</div>
              <div class="unit" style="color:#00FFFF">次</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#00FFFF">
              其他垃圾
            </div>
          </div>
          <div class="img-item">
            <div class="circle__wrapper1">
              <div class="value" style="color:#FFAE11">{{ total }}</div>
              <div class="unit" style="color:#FFAE11">次</div>
            </div>
            <div style="text-align:center;margin-top:4px;color:#FFAE11">
              清理次数
            </div>
          </div>
        </div>
        <div class="asideBg comTop">
          <span class="waterMonitorTit">使用情況</span>
          <span class="right">water monitoring</span>
        </div>
        <div class="comTop">
          <div class="percent" v-for="item in trashUseLeft">
            <span>{{ item.ddGarbageId }}</span>
            <span class="percentValue">{{ item.var4 }}</span
            ><span>m³</span>
            <div class="percentBg"></div>
            <div class="percentPrice"></div>
          </div>
          <div class="percentUnit">
            <span>{{ unit }}%</span>
          </div>
          <div style="clear:both"></div>
        </div>

        <div>
          <div class="comTop">
            <button
              class="pointLeft monitorPoint"
              style="width: 20%;margin-left: 67.5%"
            >
              查询
            </button>
          </div>

          <div class="comTop">
            <span class="monitorPoint">间隔选择</span>
            <select name="sel" v-model="timeIntervalValue">
              <option
                v-for="item in timeIntervalOptions"
                :key="item.timeIntervalValue"
                :label="item.timeIntervalLabel"
                :value="item.timeIntervalValue"
              ></option>
            </select>
            <span class="monitorPoint1">类别选择</span>
            <select name="sel" class="sel">
              <option value="1">广州</option>
              <option value="2">深圳</option>
              <option value="3">山东</option>
              <option value="4">北京</option>
            </select>
          </div>
          <div v-if="timeIntervalValue == '日'" class="comTop">
            <span class="monitorPoint">时间选择</span>
            <el-date-picker
              class="dateLeft"
              type="date"
              placeholder="选择日期"
              value-format="yyyy-MM-dd"
              @change="startTime"
              v-model="getTime1.getStartDate"
              :picker-options="pickerStartTimeDate"
            >
            </el-date-picker>
            <el-date-picker
              class="mediaStyle"
              type="date"
              placeholder="选择日期"
              @change="endTime"
              value-format="yyyy-MM-dd"
              v-model="getTime1.getEndDate"
              :picker-options="pickerEndTimeDate"
            >
            </el-date-picker>
          </div>
          <div v-if="timeIntervalValue == '月'" class="comTop">
            <span class="monitorPoint">时间选择</span>
            <el-date-picker
              class="dateLeft"
              type="month"
              placeholder="选择月"
              value-format="yyyy-MM"
              @change="startTime"
              v-model="getTime1.getStartDate"
              :picker-options="pickerStartTimeDate"
            >
            </el-date-picker>
            <el-date-picker
              class="mediaStyle"
              type="month"
              placeholder="选择月"
              value-format="yyyy-MM"
              @change="endTime"
              v-model="getTime1.getEndDate"
              :picker-options="pickerEndTimeDate"
            >
            </el-date-picker>
          </div>
          <div v-if="timeIntervalValue == '年'" class="comTop">
            <span class="monitorPoint">时间选择</span>
            <el-date-picker
              class="dateLeft"
              align="right"
              type="year"
              placeholder="选择年"
              value-format="yyyy"
              @change="startTime"
              v-model="getTime1.getStartDate"
              :picker-options="pickerStartTimeDate"
            >
            </el-date-picker>
            <el-date-picker
              class="mediaStyle"
              align="right"
              type="year"
              placeholder="选择年"
              value-format="yyyy"
              @change="endTime"
              v-model="getTime1.getEndDate"
              :picker-options="pickerEndTimeDate"
            >
            </el-date-picker>
          </div>
        </div>

        <div class="chart"></div>
      </div>
      <div class="water">
        <div class="waterMonitor">
          <div class="asideBg comTop">
            <span class="waterMonitorTit">虫情趋势</span>
            <span class="right">water monitoring</span>
          </div>
        </div>

        <div>
          <div class="comTop">
            <button
              class="pointLeft monitorPoint"
              style="width: 20%;margin-left: 67.5%"
            >
              查询
            </button>
          </div>

          <div class="comTop">
            <span class="monitorPoint">间隔选择</span>
            <select name="sel" v-model="timeIntervalValue1">
              <option
                v-for="item in timeIntervalOptions1"
                :key="item.timeIntervalValue1"
                :label="item.timeIntervalLabel"
                :value="item.timeIntervalValue1"
              ></option>
            </select>
            <span class="monitorPoint1">类别选择</span>
            <select name="sel" class="sel">
              <option value="1">广州</option>
              <option value="2">深圳</option>
              <option value="3">山东</option>
              <option value="4">北京</option>
            </select>
          </div>
          <div v-if="timeIntervalValue == '日'" class="comTop">
            <span class="monitorPoint">时间选择</span>
            <el-date-picker
              class="dateLeft"
              type="date"
              placeholder="选择日期"
              value-format="yyyy-MM-dd"
              @change="startTime"
              v-model="getTime1.getStartDate"
              :picker-options="pickerStartTimeDate"
            >
            </el-date-picker>
            <el-date-picker
              class="mediaStyle"
              type="date"
              placeholder="选择日期"
              @change="endTime"
              value-format="yyyy-MM-dd"
              v-model="getTime1.getEndDate"
              :picker-options="pickerEndTimeDate"
            >
            </el-date-picker>
          </div>
          <div v-if="timeIntervalValue == '月'" class="comTop">
            <span class="monitorPoint">时间选择</span>
            <el-date-picker
              class="dateLeft"
              type="month"
              placeholder="选择月"
              value-format="yyyy-MM"
              @change="startTime"
              v-model="getTime1.getStartDate"
              :picker-options="pickerStartTimeDate"
            >
            </el-date-picker>
            <el-date-picker
              class="mediaStyle"
              type="month"
              placeholder="选择月"
              value-format="yyyy-MM"
              @change="endTime"
              v-model="getTime1.getEndDate"
              :picker-options="pickerEndTimeDate"
            >
            </el-date-picker>
          </div>
          <div v-if="timeIntervalValue == '年'" class="comTop">
            <span class="monitorPoint">时间选择</span>
            <el-date-picker
              class="dateLeft"
              align="right"
              type="year"
              placeholder="选择年"
              value-format="yyyy"
              @change="startTime"
              v-model="getTime1.getStartDate"
              :picker-options="pickerStartTimeDate"
            >
            </el-date-picker>
            <el-date-picker
              class="mediaStyle"
              align="right"
              type="year"
              placeholder="选择年"
              value-format="yyyy"
              @change="endTime"
              v-model="getTime1.getEndDate"
              :picker-options="pickerEndTimeDate"
            >
            </el-date-picker>
          </div>
        </div>

        <div class="chart"></div>
      </div>
    </div>

    <div class="screen-right">
      <div class="screenRight">
        <div class="rightDeg">
          <span class="degreeDamage">虫情危害程度</span>
          <span class="degreeDamageEnglish">Degree of pest damage</span>
        </div>
        <div style="display:flex" class="extent">
          <span class="degree1" style="flex:1">轻</span>
          <span class="degree2" style="flex:1">中</span>
          <span class="degree3" style="flex:1">重</span>
          <span class="degree4" style="flex:1">严重</span>
        </div>
      </div>
    </div>
    <common-footer></common-footer> 
    <router-view />
  </div>
</template>
<script>
import CommonHeader from "@commons/CommonHeader";
import CommonFooter from "@commons/CommonFooter";
import insertIcon from "@assets/marker/insert.png";
import trashIcon from "@assets/marker/trash.png";

import https from "@/https.js";
export default {
  directives: {},
  mixins: [],
  components: { CommonHeader, CommonFooter },
  props: {},
  data() {
    return {
      showImgInfo: [
        { value: "20", unit: "kw/h", isMoney: false, label: "厨余垃圾" },
        { value: "20", unit: "kw/h", isMoney: false, label: "其他垃圾" },
        { value: "20", unit: "kw/h", isMoney: false, label: "可回收垃圾" },
        { value: "20", unit: "万元", isMoney: true, label: "有害垃圾" }
      ],
      electricitySomeInfo: [
        {
          label: "智能垃圾桶01",
          value: "2.3",
          unit: "次",
          progress: "34"
        },
        {
          label: "智能垃圾桶02",
          value: "2.3",
          unit: "次",
          progress: "34"
        },
        {
          label: "智能垃圾桶03",
          value: "2.3",
          unit: "次",
          progress: "34",
          uping: true
        },
        {
          label: "智能垃圾桶04",
          value: "2.3",
          unit: "次",
          progress: "34",
          uping: true
        }
      ],
      waterStartChartData: "",
      waterStartCreatTime: "",
      waterStartTypeNum: "",

      waterEndChartData: "",
      waterEndCreatTime: "",
      waterEndTypeNum: "",

      soilStartChartData: "",
      soilStartCreatTime: "",
      soilStartTypeNum: "",

      soilEndChartData: "",
      soilEndCreatTime: "",
      soilEndTypeNum: "",

      center: { lng: 0, lat: 0 },
      zoom: 3,
      nsectPoints: [],
      trashPoints: [],

      timeIntervalValue: "日",
      timeIntervalOptions: [
        {
          timeIntervalValue: "年",
          timeIntervalLabel: "年"
        },
        {
          timeIntervalValue: "月",
          timeIntervalLabel: "月"
        },
        {
          timeIntervalValue: "日",
          timeIntervalLabel: "日"
        }
      ],
      timeIntervalValue1: "日",
      timeIntervalOptions1: [
        {
          timeIntervalValue1: "年",
          timeIntervalLabel1: "年"
        },
        {
          timeIntervalValue1: "月",
          timeIntervalLabel1: "月"
        },
        {
          timeIntervalValue1: "日",
          timeIntervalLabel1: "日"
        }
      ],
      // 开始和结束时间不能超过当天
      pickerStartTimeDate: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      pickerEndTimeDate: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        }
      },
      s1: "",
      s2: "",
      total: "",
      other: "",
      pager: "",
      recyclable: "",
      trashUseLeft: [
        {
          ddGarbageId: "",
          var4: ""
        }
      ],
      unitTotal: "",
      getTime1: {
        getStartTimeDate: "",
        getEndTimeDate: ""
      },
      getTime2: {
        getStartTimeDate: "",
        getEndTimeDate: ""
      }
    }; 
  },
  computed: {},
  watch: {},
  mounted() {},
  created() {
    // this.getWateData();
    this.trashYesterDay();
    this.insertYesterDay();

    // 垃圾桶左侧
    this.trashLeft();
    this.trashUse();
  },
  methods: {
    // 垃圾桶左侧
    trashLeft() {
      var that = this;
      https
        .fetchGet("url2/trash/left")
        .then(function(response) {
          var traLeft = response.object;
          that.total = traLeft.total;
          that.other = traLeft.other;
          that.pager = traLeft.pager;
          that.recyclable = traLeft.recyclable;
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    //垃圾桶使用情况
    trashUse() {
      var that = this;
      // var unitArr = [];
      // var uesult = 0;
      https
        .fetchGet("url2/trash/now")
        .then(function(response) {
          var traLeft = response.object.list;
          console.log(traLeft);
          that.trashUseLeft = traLeft;
          console.log(...that.trashUseLeft[i].var4);

          for (var i = 0; i <= that.trashUseLeft.length; i++) {
            console.log(that.trashUseLeft[i].var4);
            // that.unitTotal = traLeft[i].var4;
            // that.resultUnit += that.unitTotal;
            // console.log(that.resultUnit);
            // unitArr.push({
            //   ...that.trashUseLeft.var4
            // });
            // console.log(unitArr);
          }
        })
        .catch(function(error) {
          console.log(error);
        });
    },

    // 垃圾桶
    drawChart() {
      let _this = this;
      let myChart1 = this.$echarts.init(document.getElementById("myChart1"));
      myChart1.setOption({
        grid: {
          y: 10,
          height: 80,
          y2: 20
        },
        xAxis: {
          type: "category",
          data: _this.waterCreatTime,
          axisLine: {
            lineStyle: {
              color: "#fff"
            }
          }
        },
        yAxis: {
          type: "value",
          axisLine: {
            lineStyle: {
              color: "#fff"
            }
          }
        },
        // color: ["#00b4fe", "#00b4fe", "#00b4fe"],
        series: [
          {
            data: _this.waterStartTypeNum,
            type: "line",
            smooth: true,
            color: "#ff0000",
            lineStyle: {
              color: "#ff0000"
            }
          },
          {
            data: _this.waterEndTypeNum,
            type: "line",
            smooth: true,
            color: "#04DDDA",
            lineStyle: {
              color: "#04DDDA"
            }
          }
        ]
      });
    },
    trashYesterDay() {
      var _this = this;
      // format 扩展函数
      Date.prototype.format = function(fmt) {
        var o = {
          "M+": this.getMonth() + 1, //月份
          "d+": this.getDate(), //日
          "h+": this.getHours(), //小时
          "m+": this.getMinutes(), //分
          "s+": this.getSeconds(), //秒
          "q+": Math.floor((this.getMonth() + 3) / 3), //季度
          S: this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt))
          fmt = fmt.replace(
            RegExp.$1,
            (this.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        for (var k in o)
          if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
        return fmt;
      };
      var day1 = new Date();
      day1.setDate(day1.getDate() - 1);
      var s1 = day1.format("yyyy-MM-dd");
      console.log(s1);
      _this.s1 = s1;
      let param = {
        startTime: _this.s1,
        endTime: _this.s1
      };
      https
        .fetchGet("/api/trash/historyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].cleanNUM;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].cleanNUM;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChart();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    trashDay() {
      var _this = this;
      let param = {
        startTime: this.getTime1.getStartTimeDate,
        endTime: this.getTime1.getEndTimeDate
      };
      https
        .fetchGet("/api/trash/historyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].cleanNUM;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].cleanNUM;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChart();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    trashMonth() {
      var _this = this;
      let param = {
        startTime: this.getTime1.getStartTimeMonth,
        endTime: this.getTime1.getEndTimeMonth
      };
      https
        .fetchGet("/api/trash/historyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].cleanNUM;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].cleanNUM;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChart();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    trashYear() {
      var _this = this;
      let param = {
        startTime: this.getTime1.getStartTimeYear,
        endTime: this.getTime1.getEndTimeYear
      };
      https
        .fetchGet("/api/trash/historyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].cleanNUM;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].cleanNUM;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChart();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    getStartDate1(value) {
      console.log("改变开始时间" + value);
      this.trashDay();
    },
    getEndDate1(value1) {
      console.log("改变结束时间" + value1);
      console.log(
        "开始时间" + this.getTime1.getStartTimeDate + "结束时间" + value1
      );
      this.trashDay();
    },
    getStartMonth1(value) {
      console.log("改变开始时间" + value);
      this.trashMonth();
    },
    getEndMonth1(value1) {
      console.log("改变结束时间" + value1);
      console.log(
        "开始时间" + this.getTime1.getStartTimeMonth + "结束时间" + value1
      );
      this.trashMonth();
    },
    getStartYear1(value) {
      console.log("改变开始时间" + value);
      this.trashYear();
    },
    getEndYear1(value1) {
      console.log("改变结束时间" + value1);
      console.log(
        "开始时间" + this.getTime1.getStartTimeYear + "结束时间" + value1
      );
      this.trashYear();
    },
    // 虫情趋势
    drawChartInsert() {
      let _this = this;
      let myChart2 = this.$echarts.init(document.getElementById("myChart2"));
      myChart2.setOption({
        grid: {
          y: 10,
          height: 80,
          y2: 20
        },
        xAxis: {
          type: "category",
          data: _this.soilStartCreatTime,
          axisLine: {
            lineStyle: {
              color: "#fff"
            }
          }
        },
        yAxis: {
          type: "value",
          axisLine: {
            lineStyle: {
              color: "#fff"
            }
          }
        },
        series: [
          {
            data: _this.soilStartTypeNum,
            type: "line",
            smooth: true,
            color: "#ff0000",
            lineStyle: {
              color: "#ff0000"
            },
            label: {
              normal: {
                show: true,
                position: "top"
              }
            }
          },
          {
            data: _this.soilEndTypeNum,
            type: "line",
            smooth: true,
            color: "#04DDDA",
            lineStyle: {
              color: "#04DDDA"
            },
            label: {
              normal: {
                show: true,
                position: "top"
              }
            }
          }
        ]
      });
    },
    insertYesterDay() {
      var _this = this;
      // format 扩展函数
      Date.prototype.format = function(fmt) {
        var o = {
          "M+": this.getMonth() + 1, //月份
          "d+": this.getDate(), //日
          "h+": this.getHours(), //小时
          "m+": this.getMinutes(), //分
          "s+": this.getSeconds(), //秒
          "q+": Math.floor((this.getMonth() + 3) / 3), //季度
          S: this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt))
          fmt = fmt.replace(
            RegExp.$1,
            (this.getFullYear() + "").substr(4 - RegExp.$1.length)
          );
        for (var k in o)
          if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(
              RegExp.$1,
              RegExp.$1.length == 1
                ? o[k]
                : ("00" + o[k]).substr(("" + o[k]).length)
            );
        return fmt;
      };
      var day1 = new Date();
      day1.setDate(day1.getDate() - 1);
      var s2 = day1.format("yyyy-MM-dd");
      console.log(s2);
      _this.s2 = s2;
      let param = {
        startTime: _this.s2,
        endTime: _this.s2
      };
      console.log(param);
      https
        .fetchGet("/api/insect/getHistroyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].insectNum;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].insectNum;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChartInsert();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    insertDay() {
      var _this = this;
      let param = {
        startTime: this.getTime1.getStartTimeDate,
        endTime: this.getTime1.getEndTimeDate
      };
      https
        .fetchGet("/api/insect/getHistroyList", param)
        .then(function(response) {
          // debugger;
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].insectNum;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].insectNum;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChartInsert();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    insertMonth() {
      var _this = this;
      let param = {
        startTime: this.getTime1.getStartTimeMonth,
        endTime: this.getTime1.getEndTimeMonth
      };
      https
        .fetchGet("/api/insect/getHistroyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].insectNum;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          for (var i = 0; i < _this.waterEndChartData.length; i++) {
            _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
            _this.waterEndTypeNum[i] = _this.waterEndChartData[i].insectNum;
          }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChartInsert();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    insertYear() {
      var _this = this;
      let param = {
        startTime: this.getTime1.getStartTimeYear,
        endTime: this.getTime1.getEndTimeYear
      };
      https
        .fetchGet("/api/insect/getHistroyList", param)
        .then(function(response) {
          console.log(response);
          console.log(response.object.list);
          // 开始
          _this.waterStartChartData = response.object.list;
          _this.waterStartCreatTime = [];
          _this.waterStartTypeNum = [];
          for (var i = 0; i < _this.waterStartChartData.length; i++) {
            _this.waterStartCreatTime[i] =
              _this.waterStartChartData[i].createTime;
            _this.waterStartTypeNum[i] = _this.waterStartChartData[i].insectNum;
          }
          console.log(_this.waterStartCreatTime);
          console.log(_this.waterStartTypeNum);
          // 结束
          _this.waterEndChartData = response.object.contrastList;
          _this.waterEndCreatTime = [];
          _this.waterEndTypeNum = [];
          // for (var i = 0; i < _this.waterEndChartData.length; i++) {
          //   _this.waterEndCreatTime[i] = _this.waterEndChartData[i].createTime;
          //   _this.waterEndTypeNum[i] = _this.waterEndChartData[i].insectNum;
          // }
          console.log(_this.waterEndCreatTime);
          console.log(_this.waterEndTypeNum);
          _this.drawChartInsert();
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    getStartDate2(value) {
      console.log("改变开始时间" + value);
      this.insertDay();
    },
    getEndDate2(value1) {
      console.log("改变结束时间" + value1);
      console.log(
        "开始时间" + this.getTime2.getStartTimeDate + "结束时间" + value1
      );
      this.insertDay();
    },
    getStartMonth2(value) {
      console.log("改变开始时间" + value);
      this.insertMonth();
    },
    getEndMonth2(value1) {
      console.log("改变结束时间" + value1);
      console.log(
        "开始时间" + this.getTime2.getStartTimeMonth + "结束时间" + value1
      );
      this.insertMonth();
    },
    getStartYear2(value) {
      console.log("改变开始时间" + value);
      this.insertYear();
    },
    getEndYear2(value1) {
      console.log("改变结束时间" + value1);
      console.log(
        "开始时间" + this.getTime2.getStartTimeYear + "结束时间" + value1
      );
      this.insertYear();
    },
    handler({ BMap, map }) {
      var _this = this;
      // 地图中心点
      this.center.lng = 116.302281;
      this.center.lat = 39.992571;
      this.zoom = 17;
      // var mapStyle = { style: "midnight" };
      // map.setMapStyle(mapStyle);
      map.enableScrollWheelZoom();
      // 虫情
      https
        .fetchGet("/url2/insect/now")
        .then(function(response) {
          console.log(response.object.list);
          var insectData = response.object.list;
          console.log(insectData);
          var insectPoints = [];
          for (var i = 0; i < insectData.length; i++) {
            insectPoints.push({
              x: insectData[i].latitude,
              y: insectData[i].longitude,
              inseName: insectData[i].insectName,
              inseNum: insectData[i].insectNum
            });
          }
          _this.insectPoints = insectPoints;

          for (var i = 0; i < _this.insectPoints.length; i++) {
            var content = `<div class="deviceBg">`;
            content =
              content +
              `<div class="title" style=" display: flex">
              <button id="insertInfo"  class="eleTit" style="flex:2;border: none;background-color: transparent;outline: none;">` +
              _this.insectPoints[i].inseName +
              `</button>
              <button id="insertTab" class="eleTit" style="flex:1;border: none;background-color: transparent;outline: none;">报表</button>
              </div>`;
            content = content + `<div id="insertInfoCon">`;
            content =
              content +
              `<p>今日监测数值:` +
              _this.insectPoints[i].inseNum +
              `</p>`;
            content = content + `</div>`;
            content =
              content +
              `<div class="reportFrom" id="insertTabCon" style="display:none">`;
            content = content + `<span >报表</span>`;
            content = content + ` </div>`;
            content += `</div>`;
            var points = new BMap.Point(
              _this.insectPoints[i].y,
              _this.insectPoints[i].x
            );
            //创建坐标点
            var opts = {
              width: 250,
              height: 120
            };
            var infoWindows = new BMap.InfoWindow(content, opts);
            markerFun(points, infoWindows);
          }

          function markerFun(points, infoWindows) {
            var myIcon = new BMap.Icon(insertIcon, new BMap.Size(29, 37));
            var markers = new BMap.Marker(points, { icon: myIcon });
            map.addOverlay(markers);

            var label = new BMap.Label(_this.insectPoints[i].inseName, {
              offset: new BMap.Size(-50, 32)
            });
            var labelStyle = {
              border: "0",
              color: "#000000"
            };
            label.setStyle(labelStyle);
            markers.setLabel(label);

            markers.addEventListener("click", function() {
              // debugger;
              map.openInfoWindow(infoWindows, points); //参数：窗口、点  根据点击的点出现对应的窗口
            });

            if (!infoWindows.isOpen()) {
              infoWindows.addEventListener("open", function() {
                var insertInfo = document.getElementById("insertInfo");
                insertInfo.onclick = function() {
                  console.log("监测点");
                  document.getElementById("insertInfoCon").style.display =
                    "block";
                  document.getElementById("insertTabCon").style.display =
                    "none";
                };
                var insertTab = document.getElementById("insertTab");
                insertTab.onclick = function() {
                  console.log("报表");
                  document.getElementById("insertInfoCon").style.display =
                    "none";
                  document.getElementById("insertTabCon").style.display =
                    "block";
                };
              });
            }
          }

          console.log(content);
        })
        .catch(function(error) {
          console.log(error);
        });
      //  垃圾桶
      https
        .fetchGet("/url2/trash/now")
        .then(function(response) {
          console.log(response.object.list);
          var trashData = response.object.list;
          console.log(trashData);
          var trashPoints = [];
          for (var i = 0; i < trashData.length; i++) {
            trashPoints.push({
              x: trashData[i].latitude,
              y: trashData[i].longitude,
              ddGarbeagePaper: trashData[i].ddGarbeagePaper,
              ddGarbeageRecyclable: trashData[i].ddGarbeageRecyclable,
              ddGarbeageOther: trashData[i].ddGarbeageOther,
              ddGarbageId: trashData[i].ddGarbageId
            });
          }
          _this.trashPoints = trashPoints;
          console.log(_this.trashPoints);
          for (var i = 0; i < _this.trashPoints.length; i++) {
            var content = `<div class="deviceBg">`;
            content =
              content +
              `<div class="title" style=" display: flex">
              <button id="trashInfo"  class="eleTit" style="flex:1.5;border: none;background-color: transparent;outline: none;">智能监测点</button>
              <button id="trashTab" class="eleTit" style="flex:1;border: none;background-color: transparent;outline: none;">报表</button>
              </div>`;
            content = content + `<div id="trashInfoCon">`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">设备状态:` +
              `设备不在线` +
              `</p>`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">纸类垃圾满溢度:` +
              _this.trashPoints[i].ddGarbeagePaper +
              `</p>`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">可回收垃圾满溢度:` +
              _this.trashPoints[i].ddGarbeageRecyclable +
              `</p>`;
            content =
              content +
              `<p style="line-height:20px;margin:0px;margin-left:10px">其他垃圾满溢度:` +
              _this.trashPoints[i].ddGarbeageOther +
              `</p>`;
            content = content + `</div>`;
            content =
              content +
              `<div class="reportForm" id="trashTabCon" style="display:none">`;
            content = content + `<span>ph</span>`;
            content = content + ` </div>`;
            content += `</div>`;
            var points = new BMap.Point(
              _this.trashPoints[i].y,
              _this.trashPoints[i].x
            ); //创建坐标点
            var opts = {
              width: 250,
              height: 180
            };
            var infoWindows = new BMap.InfoWindow(content, opts);
            markerFun(points, infoWindows);
          }
          function markerFun(points, infoWindows) {
            var myIcon = new BMap.Icon(trashIcon, new BMap.Size(27, 38));
            var markers = new BMap.Marker(points, { icon: myIcon });
            // 把标注添加到地图上
            map.addOverlay(markers);
            var label = new BMap.Label(_this.trashPoints[i].ddGarbageId, {
              offset: new BMap.Size(-50, 32)
            });
            var labelStyle = {
              border: "0",
              color: "#000000"
            };
            label.setStyle(labelStyle);
            markers.setLabel(label);
            markers.addEventListener("click", function() {
              // debugger;
              map.openInfoWindow(infoWindows, points); //参数：窗口、点  根据点击的点出现对应的窗口
            });
            if (!infoWindows.isOpen()) {
              infoWindows.addEventListener("open", function() {
                var trashInfo = document.getElementById("trashInfo");
                trashInfo.onclick = function() {
                  console.log("监测点");
                  document.getElementById("trashInfoCon").style.display =
                    "block";
                  document.getElementById("trashTabCon").style.display = "none";
                };
                var trashTab = document.getElementById("trashTab");
                trashTab.onclick = function() {
                  console.log("报表");
                  document.getElementById("trashInfoCon").style.display =
                    "none";
                  document.getElementById("trashTabCon").style.display =
                    "block";
                };
              });
            }
          }
          console.log(content);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    // 垃圾桶对比 默认昨天的数据
    getTrashBinData() {
      let params = {
        startTime: "2019-08-03",
        endTime: "2019-08-04",
        deviceId: "34"
      };
      https
        .fetchGet("/trash/historyList", params)
        .then(function(response) {
          console.log(response.object.list);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    //虫情图表  默认
    getInsectPestSituaDefalutData() {
      https
        .fetchGet("/insect/getYesterDay")
        .then(function(response) {
          console.log(response.object.list);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    //地图 垃圾桶位置
    getTrashBinLocationData() {
      https
        .fetchGet("/trash/now")
        .then(function(response) {
          console.log(response.object.list);
        })
        .catch(function(error) {
          console.log(error);
        });
    },
    //地图 虫情位置
    getInsertData() {
      https
        .fetchGet("/insect/now")
        .then(function(response) {
          console.log(response.object.list);
        })
        .catch(function(error) {
          console.log(error);
        });
    }
  }
};
</script>
<style lang="stylus" scoped></style>

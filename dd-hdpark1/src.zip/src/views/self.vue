<template>
  <div style="padding: 20px;">
    <el-button type="primary" style="margin:10px">自动</el-button>
  </div>
</template>
<script>
// import https from "@/https.js";
// import axios from "axios";
export default {
  data() {
    return {};
  },
  created() {},
  computed: {},
  mounted() {},
  methods: {}
};
</script>
<style scoped lang="scss">
</style>
